package abl.frd.qremit.converter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
